# Doublet detection in Single-Cell RNA Seq data via Semi-supervised Adversarial Autoencoder
### video link: https://youtu.be/EHQwa2b0Th0
